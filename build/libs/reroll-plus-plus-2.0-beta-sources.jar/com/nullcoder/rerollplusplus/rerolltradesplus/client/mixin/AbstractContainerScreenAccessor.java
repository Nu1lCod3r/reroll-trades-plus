package com.nullcoder.rerollplusplus.client.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {

	@Accessor("leftPos")
	int rerollTradesPlus$getLeftPos();

	@Accessor("topPos")
	int rerollTradesPlus$getTopPos();

}
